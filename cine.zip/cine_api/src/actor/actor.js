export const Actor = {
  // _id: ObjectId
  idPelicula: 'string', // almacenamos id de pelicula como string
  nombre: 'string',
  edad: 'int',
  estaRetirado: 'bool',
  premios: ['string']
};
