export const Pelicula = {
  // _id: ObjectId
  nombre: 'string',
  generos: ['string'],
  anioEstreno: 'int'
};
